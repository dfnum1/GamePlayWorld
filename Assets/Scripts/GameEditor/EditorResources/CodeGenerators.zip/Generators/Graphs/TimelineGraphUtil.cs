﻿//auto generator
namespace Framework.Core
{
	public class TimelineGraphUtil 
	{
		static System.Collections.Generic.Dictionary<System.Type, int> ms_TypeIds = null;
		//------------------------------------------------------
		public static void Init()
		{
		}
		//------------------------------------------------------
		public static Framework.Core.AGraphTrack NewTrack(int typeId)
		{
			return null;
		}
		//------------------------------------------------------
		public static Framework.Core.AGraphClip NewClip(int typeId)
		{
			return null;
		}
		//------------------------------------------------------
		public static Framework.Core.AGraphEvent NewEvent(int typeId)
		{
			return null;
		}
		//------------------------------------------------------
		public static int GetTypeId(System.Type type)
		{
			return 0;
		}
	}
}
