﻿//auto generator
using Framework.UI;
namespace TopGame.UI
{
	public partial class UIBinderBuilder
	{
		public static UIBase Create(int type)
		{
			return null;
		}
		static System.Collections.Generic.Dictionary<System.Type, int> ms_vUITypeMaps = null;
		static void CheckTypeMapping()
		{
		}
		public static int GetTypeToUIType(System.Type type)
		{
			return 0;
		}
	}
}
