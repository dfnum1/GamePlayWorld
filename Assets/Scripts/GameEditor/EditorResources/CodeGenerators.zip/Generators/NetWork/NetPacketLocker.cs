﻿/********************************************************************
作    者:	自动生成
描    述:
*********************************************************************/
using Framework.Net;
using System.Collections.Generic;
namespace TopGame.Net
{
	public class NetPacketLocker
	{
		public static void LockPacket(int mid, HashSet<int> vLockMsg, Dictionary<int, long> vTimerLockMsg)
		{
			switch(mid)
			{
			}
		}
		public static void UnLockPacket(int mid, HashSet<int> vLockMsg, Dictionary<int, long> vTimerLockMsg)
		{
			vTimerLockMsg.Remove(mid);
			switch(mid)
			{
			}
		}
	}
}
