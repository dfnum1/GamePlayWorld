﻿/********************************************************************
作    者:	自动生成
描    述:
*********************************************************************/
using Framework.Net;
namespace TopGame.Net
{
	public static class NetHandlerRegister
	{
		public static void Init(NetHandler handler)
		{
		}
	}
}
