﻿//auto generator
namespace TopGame.Net
{
	public class DBTypeMapping 
	{
		public static int GetTypeIndex(System.Type type)
		{
			return -1;
		}
		public static System.Type GetDBType( EDBType type)
		{
			return null;
		}
		public static AProxyDB NewProxyDB(EDBType type, User user)
		{
			return null;
		}
	}
}
