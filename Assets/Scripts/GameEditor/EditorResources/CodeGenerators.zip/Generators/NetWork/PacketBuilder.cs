﻿/********************************************************************
生成日期:	24:8:2023   18:53
作    者:	自动生成
描    述:
*********************************************************************/
using Framework.Net;

namespace TopGame.Net
{
	[PacketBuilderCall]
	public static class PacketBuilder
	{
		public static Google.Protobuf.IMessage newBuilder(int code, byte[] pDatas, int offset, int nLenth)
		{
			return null;
		}
		public static int getMessageCode(System.Type type)
		{
			return 0;
		}

		public static Google.Protobuf.IMessage newMessageByCode(int code)
		{
			return null;
		}

    }
}
