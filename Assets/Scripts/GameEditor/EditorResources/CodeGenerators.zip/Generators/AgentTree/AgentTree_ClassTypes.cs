﻿//auto generator
using System;
using System.Collections.Generic;
namespace Framework.Plugin.AT
{
	public static class AgentTree_ClassTypes
	{
		static Dictionary<System.Type, int> ms_vClassTypeToHash = new Dictionary<System.Type, int>();
		public static int ClassTypeToHash(System.Type classType)
		{
			return 0;
		}
		public static System.Type HashToClassType(int hashCode)
		{
			return null;
		}
		public static int HashToParentHash(int hashCode)
		{
			return 0;
		}
	}
}
