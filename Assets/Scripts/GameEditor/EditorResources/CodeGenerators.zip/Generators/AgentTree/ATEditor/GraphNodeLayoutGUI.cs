﻿#if UNITY_EDITOR
//auto generator
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEditor;
using System.Linq;
namespace Framework.Plugin.AT
{
	[GraphNodeDrawProperty]
	public partial class GraphNodeLayoutGUI
	{
		[GraphNodeDrawProperty]
		public static bool DrawProperty(GraphNode pNode)
		{
			return false;
		}
	}
}
#endif
