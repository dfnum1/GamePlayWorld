﻿//auto generator
using System;
namespace Framework.Plugin.AT
{
	public static class AgentTreeUserClass_Func
	{
		public static bool DoInerAction(AgentTreeTask pTask, ActionNode pAction, int functionId = 0)
		{
			return true;
		}
	}
}
