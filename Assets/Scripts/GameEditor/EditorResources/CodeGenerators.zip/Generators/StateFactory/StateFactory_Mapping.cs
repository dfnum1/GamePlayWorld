﻿//auto generator
using UnityEngine;
namespace TopGame.Logic
{
	public partial class StateFactory 
	{
		static EGameState GetState(System.Type type)
		{
			return EGameState.Count;
		}
		static System.Type GetType(EGameState state)
		{
			return null;
		}
		static AState NewState(EGameState state)
		{
			return null;
		}
		static ushort GetSceneID(EGameState state, EMode mode = EMode.None)
		{
			return 0;
		}
		static uint GetClearFlags(EGameState state,EGameState toState)
		{
			return 0;
		}
		public static bool DeltaChangeState(EGameState state)
		{
			return false;
		}
		public static TopGame.UI.ELoadingType GetModeLoadingType(EMode mode)
		{
			return TopGame.UI.ELoadingType.Loading;
		}
		void RegisterMode(AState pState, EMode mode)
		{
		}
		AbsMode CreateMode(EMode mode)
		{
			return null;
		}
		static void RegisterStateLogic(AState pState, EGameState state)
		{
		}
	}
}
